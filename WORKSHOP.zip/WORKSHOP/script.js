var app = angular.module("myApp", ["ngRoute","xeditable"]);
app.config(function($routeProvider) {
    $routeProvider
	.when("/table", {
        templateUrl : "viewTable.html",
        controller : "retrvData"
    })
    .when("/addbook", {
        templateUrl : "addbook.html",
        controller : "addbookCtrl"
    })
    .when("/addauthor", {
        templateUrl : "addauthor.html",
        controller : "addauthorCtrl"
    })
	 
	.when("/displayBook",
	{
		templateUrl : "displayBook.html",
		controller : "displayBook"
	})
	
	.when("/displayAuthor",
	{
		templateUrl : "displayAuthor.html",
		controller : "displayAuthr"
	})
	
	.when("/editBook",
	{
		templateUrl : "editBook.html",
		controller : "editBookCtrl"
	})
	
	.when("/deleteBook",
	{
		templateUrl : "deleteBook.html",
		controller : "deleteBookCtrl"
	})
	
	.when("/editAuthor",
	{
		templateUrl : "editAuthor.html",
		controller : "editAuthorCtrl"
	})
	.when("/deleteAuthor",
	{
		templateUrl : "deleteAuthor.html",
		controller : "editAuthorCtrl"
	});
});

app.controller('retrvData',function($scope,$http)
{
	$http.get("http://172.27.12.104:3000/book/list")
	.then(function(response)
	{
		$scope.myData = response.data;
	});
	
});

app.controller("addbookCtrl", function ($scope,$http)
{
	alert('In controller');
	$scope.availableon = [{a:'ebay'},
							{a:'flipkart'},
							{a:'Amazon'},
							];
		$scope.selection=[];
		// toggle selection for a given employee by name
		$scope.toggleSelection = function toggleSelection(availOn) {
	    var idx = $scope.selection.indexOf(availOn);

	    // is currently selected
	    if (idx > -1) {
	      $scope.selection.splice(idx, 1);
	    }

	    // is newly selected
	    else {
	      $scope.selection.push(availOn);
	    }
	  };
	 
	  console.log($scope.selection);
	  
	$scope.postData = function()
	{
		alert('In function');
	
		var data = {
                isbn: $scope.isbn,
                title: $scope.title,
                author:$scope.author,
                price:$scope.price,
				availableOn : $scope.selection 
			};
	
        
			$http({
				method: 'POST',
				url: 'http://172.27.12.104:3000/book/new',
				data: data
			})
			.then(function(response) {
				console.log(response.data);
			}, function(rejection) {
				console.log(rejection.data);
			});
	};
	
});
app.controller('addauthorCtrl', function ($scope,$http) 
{
		alert('In controller');
		$scope.skills = [{l:'HTML'},
							{l:'CSS'},
							{l:'JAVASCRIPT'},
							{l:'NODEJS'},
							{l:'ANGULARJS'},
							];
		$scope.selection=[];
		// toggle selection for a given employee by name
		$scope.toggleSelection = function toggleSelection(skill) {
	    var idx = $scope.selection.indexOf(skill);

	    // is currently selected
	    if (idx > -1) {
	      $scope.selection.splice(idx, 1);
	    }

	    // is newly selected
	    else {
	      $scope.selection.push(skill);
	    }
	  };
	 
	  console.log($scope.selection);
	  
			$scope.postAuthData = function()
			{
			 var data = {
                empid: $scope.empid,
                name: $scope.name,
				email:$scope.email,
				skills :$scope.selection,
				department:$scope.department,
				website:$scope.website
			};
			console.log(data);
			$http({
				method: 'POST',
				url: 'http://172.27.12.104:3000/author/new',
				data: data
			})
			.then(function(response) {
				console.log(response.data);
			}, function(rejection) {
				console.log(rejection.data);
			});
	};
	
});

app.controller('displayBook', function($scope,$http,$location)
{

	$http.get("http://172.27.12.104:3000/book/list")
	.then(function(response)
	{
		$scope.detail = response.data;
		$scope.bookisbn = $location.search();
		
		for(var i in $scope.detail)
		{
			if($scope.bookisbn.isbn === $scope.detail[i].isbn)
			{
				$scope.PostDataResponse = $scope.detail[i];
			}
		}
		
	});
	
});

app.controller('displayAuthr', function($scope,$http,$location)
{
	$http.get("http://172.27.12.104:3000/author/list")
	.then(function(response)
	{
		$scope.details = response.data;
		$scope.author = $location.search();
		console.log($scope.author);
		for(var i in $scope.details)
		{
			if($scope.author.name === $scope.details[i].name)
			{
				$scope.PostDataResponse = $scope.details[i];
			}
		}
	});
});

app.controller('deleteBookCtrl', function($scope,$http,$location)
{
	$scope.isbn = $location.search();
	console.log($scope.isbn);
	alert("in controller");
		var data =$.param({
			isbn : $scope.isbn.isbn
		});
		
				$http({
				method: 'DELETE',
				url: 'http://172.27.12.104:3000/book/remove',
				data: data,
				headers: {
					'Content-type': 'application/x-www-form-urlencoded'
				}
			})
			.then(function(response) {
				console.log(response.data);
			}, function(rejection) {
				console.log(rejection.data);
			});
});


app.controller('editBookCtrl',function($scope,$http,$location)
{
			$scope.book = $location.search();
			console.log($scope.isbn);
		console.log("In edit controller");
		
		$scope.editBk = function()
		{
		var data = $.param({
					isbn : $scope.book.isbn,
					title : $scope.newTitle,
					author : $scope.newAuthor,
					price : $scope.newPrice
				});
        
				$http({
				method: 'PUT',
				url: 'http://172.27.12.104:3000/book/update',
				data: data,
				headers: {
					'Content-type': 'application/x-www-form-urlencoded'
				}
			})
			.then(function(response) {
				console.log(response.data);
			}, function(rejection) {
				console.log(rejection.data);
			});
		};
			console.log("out edit controller");
		
});


app.controller('deleteAuthorCtrl', function($scope,$http,$location)
{
	$scope.id = $location.search();
	console.log($scope.id);
	alert("in controller");
		var data =$.param({
			empid : $scope.id.empid
		});
		
				$http({
				method: 'DELETE',
				url: 'http://172.27.12.104:3000/author/remove',
				data: data,
				headers: {
					'Content-type': 'application/x-www-form-urlencoded'
				}
			})
			.then(function(response) {
				console.log(response.data);
			}, function(rejection) {
				console.log(rejection.data);
			});
});

app.controller('editAuthorCtrl',function($scope,$http,$location)
{
			$scope.empid = $location.search();
			console.log($scope.id);
		console.log("In edit controller");
			$scope.skills = [{l:'HTML'},
							{l:'CSS'},
							{l:'JAVASCRIPT'},
							{l:'NODEJS'},
							{l:'ANGULARJS'},
							];
		$scope.selection=[];
		// toggle selection for a given employee by name
		$scope.toggleSelection = function toggleSelection(skill) {
	    var idx = $scope.selection.indexOf(skill);

	    // is currently selected
	    if (idx > -1) {
	      $scope.selection.splice(idx, 1);
	    }

	    // is newly selected
	    else {
	      $scope.selection.push(skill);
	    }
	  };
	 	   $scope.user = 
	   {
		"empid" : $scope.empid.empid
	   };
	   
	   console.log($scope.user.empid);
		$scope.editAuthData = function()
		{
		var data = {
					empid : $scope.empid.empid,
					name : $scope.newName,
					email : $scope.newEmail,
					skills : $scope.selection,
					department : $scope.newDepartment,
					website : $scope.newWebsite
				};
       

				$http({
				method: 'PUT',
				url: 'http://172.27.12.104:3000/Author/update',
				data: data,
				/*headers: {
					'Content-type': 'application/x-www-form-urlencoded'
				}*/
				
			})
			.then(function(response) {
				console.log(response.data);
			}, function(rejection) {
				console.log(rejection.data);
			});
		};
			console.log("out edit controller");
		
});



