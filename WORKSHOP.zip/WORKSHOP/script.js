var app = angular.module("myApp", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
    .when("/addbook", {
        templateUrl : "addbook.html",
        controller : "addbookCtrl"
    })
    .when("/addauthor", {
        templateUrl : "addauthor.html",
        controller : "addauthorCtrl"
    });

	  
});


app.controller("addauthorCtrl", function ($scope) 
{
		
});

app.controller('retrvData',function($scope,$http)
{
	
	$http.get("http://172.27.12.104:3000/book/list")
	.then(function(response)
	{
		$scope.myData = response.data;
	})
});

app.controller("addbookCtrl", function ($scope,$http)
{
	$scope.postData = function()
	{
		var dataObj = [{
				isbn = $scope.isbn,
				title = $scope.title,
				author = $scope.author,
				price = $scope.price
			}];
		
		var config = {
			header :
			{
				ContentType = "application/json";
			}
		}
		
		$http.post("authorData.json",dataObj,config);
	};
});
