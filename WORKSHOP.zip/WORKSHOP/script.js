var app = angular.module("myApp", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
    .when("/addbook", {
        templateUrl : "addbook.html",
        controller : "addbookCtrl"
    })
    .when("/addauthor", {
        templateUrl : "addauthor.html",
        controller : "addauthorCtrl"
    })
	 
	.when("/displayAuth",
	{
		templateUrl : "AuthorProfile.html",
		controller : "displayAuthr"
	});
});

app.controller("addbookCtrl", function ($scope,$http,$location)
{
	
	 
	$scope.postData = function()
	{
		var data = $.param({
                isbn: $scope.isbn,
                title: $scope.title,
                author:$scope.author,
                price:$scope.price
			});
	
        
	var config = {
                headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
		
            $http.post('http://172.27.12.104:3000/book/new', data, config)
            .success(function (data, status, headers, config) {
                $scope.PostDataResponse = data;
            })
            .error(function (data, status, header, config) {
                $scope.ResponseDetails = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });
	}
	
});
app.controller('addauthorCtrl', function ($scope,$http) 
{
			$scope.postAuthData = function()
			{
	
	
			var data = $.param({
                empid: $scope.empid,
                name: $scope.name,
               email:$scope.email,
               department:$scope.department,
			   website:$scope.website
			});
        
	var config = {
                headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
		
            $http.post('http://172.27.12.104:3000/author/new', data, config)
            .success(function (data, status, headers, config) {
                $scope.PostDataResponseAuth = data;
            })
            .error(function (data, status, header, config) {
                $scope.ResponseDetails = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });
	}
});

app.controller('displayAuthr', function($scope,$http)
{
	alert("in a controller");
	var x = document.URL;
	var sp = x.split("=");
	$scope.author_name = sp[1];
	var name=sp[1];
	var data = $.param({
		empid : $scope.empid,
		name : $scope.name,
		email : $scope.email,
		department : $scope.department,
		website : $scope.website
	});
	
	var config = {
                headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
			
	$http.post('http://172.27.12.104:3000/author/byname', data, config)
            .success(function (data, status, headers, config) {
                $scope.PostDataResponse = data;
            })
            .error(function (data, status, header, config) {
                $scope.ResponseDetails = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });
			
			alert("in a controller");
});


app.controller('retrvData',function($scope,$http)
{
	$http.get("http://172.27.12.104:3000/book/list")
	.then(function(response)
	{
		$scope.myData = response.data;
	});
	
});