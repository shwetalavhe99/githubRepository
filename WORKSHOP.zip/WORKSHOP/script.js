var app = angular.module("myApp", ["ngRoute"]);
app.config(function($routeProvider) {
    $routeProvider
	.when("/table", {
        templateUrl : "viewTable.html",
        controller : "retrvData"
    })
    .when("/addbook", {
        templateUrl : "addbook.html",
        controller : "addbookCtrl"
    })
    .when("/addauthor", {
        templateUrl : "addauthor.html",
        controller : "addauthorCtrl"
    })
	 
	.when("/displayBook",
	{
		templateUrl : "displayBook.html",
		controller : "displayBook"
	})
	
	.when("/displayAuthor",
	{
		templateUrl : "displayAuthor.html",
		controller : "displayAuthr"
	});
});

app.controller('retrvData',function($scope,$http)
{
	$http.get("http://172.27.12.104:3000/book/list")
	.then(function(response)
	{
		$scope.myData = response.data;
	});
	
});

app.controller("addbookCtrl", function ($scope,$http)
{
	
	 
	$scope.postData = function()
	{
		var data = $.param({
                isbn: $scope.isbn,
                title: $scope.title,
                author:$scope.author,
                price:$scope.price
			});
	
        
	var config = {
                headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
		
            $http.post('http://172.27.12.104:3000/book/new', data, config)
            .success(function (data, status, headers, config) {
                $scope.PostDataResponse = data;
            })
            .error(function (data, status, header, config) {
                $scope.ResponseDetails = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });
	};
	
});
app.controller('addauthorCtrl', function ($scope,$http) 
{
			$scope.postAuthData = function()
			{
	
	
			var data = $.param({
                empid: $scope.empid,
                name: $scope.name,
               email:$scope.email,
               department:$scope.department,
			   website:$scope.website
			});
        
	var config = {
                headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }
		
            $http.post('http://172.27.12.104:3000/author/new', data, config)
            .success(function (data, status, headers, config) {
                $scope.PostDataResponseAuth = data;
            })
            .error(function (data, status, header, config) {
                $scope.ResponseDetails = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });
	};
});

app.controller('displayBook', function($scope,$http,$rootScope)
{

	/*$http.get("http://172.27.12.104:3000/book/list")
	.then(function(response)
	{
		$scope.detail = response.data;
		$scope.bookisbn = $location.search();
		
		for(var i in $scope.detail)
		{
			if($scope.bookisbn === $scope.detail[i].isbn)
			{
				$scope.PostDataResponse = $scope.detail[i];
				
			}
		}
	});*/
	$rootScope.display = function(bk)
	{
			   $scope.book=bk;
			   
            var data = $.param({
                isbn:$scope.book.isbn,
				title:$scope.book.title,
				author:$scope.book.author,
				price:$scope.book.price,
				availableOn:$scope.book.availableOn
            });
        
            var config = {
                headers : {
                    'Content-Type': 'application/x-www-form-urlencoded'
                }
            }

            $http.post('http://172.27.12.104:3000/book/byisbn', data, config)
            .success(function (data, status, headers, config) {
                $rootScope.PostDataResponse = data;
            })
            .error(function (data, status, header, config) {
                $rootScope.ResponseDetails = "Data: " + data +
                    "<hr />status: " + status +
                    "<hr />headers: " + header +
                    "<hr />config: " + config;
            });
        };
	
});

app.controller('displayAuthr', function($scope,$http,$location)
{
	$http.get("http://172.27.12.104:3000/author/list")
	.then(function(response)
	{
		$scope.details = response.data;
		$scope.author = $location.search();
		for(var i in $scope.details)
		{
			if($scope.author.name === $scope.details[i].name)
			{
				$scope.PostDataResponse = $scope.details[i];
				console.log($scope.author);
			}
		}
	});
});








