//This script contains the routing of pages.

app.config(function($routeProvider) {
    $routeProvider
	.when("/table", {
        templateUrl : "assets/views/viewTable.html",
        controller : "retrvData"
    })
    .when("/addbook", {
        templateUrl : "assets/views/addbook.html",
        controller : "addbookCtrl"
    })
    .when("/addauthor", {
        templateUrl : "assets/views/addauthor.html",
        controller : "addauthorCtrl"
    })
	 
	.when("/displayBook",
	{
		templateUrl : "assets/views/displayBook.html",
		controller : "displayBook"
	})
	
	.when("/displayAuthor",
	{
		templateUrl : "assets/views/displayAuthor.html",
		controller : "displayAuthr"
	})
	
	.when("/editBook",
	{
		templateUrl : "assets/views/editBook.html",
		controller : "editBookCtrl"
	})
	
	.when("/deleteBook",
	{
		templateUrl : "assets/views/deleteBook.html",
		controller : "deleteBookCtrl"
	})
	
	.when("/editAuthor",
	{
		templateUrl : "assets/views/editAuthor.html",
		controller : "editAuthorCtrl"
	})
	.when("/deleteAuthor",
	{
		templateUrl : "assets/views/deleteAuthor.html",
		controller : "editAuthorCtrl"
	});
});


