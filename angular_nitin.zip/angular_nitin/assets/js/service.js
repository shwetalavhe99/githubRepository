//Script for Service.

app.service('myService',['$http',function($http)
{
	//add function for adding new book or author.
	this.add=function(data,url)		
	{
		console.log(data);
		return $http(
			{
				method: 'POST',
				url:url,
				data: data
			});console.log("Out of service");
	};
	
	//update function for updating  book or author.
	this.update=function(data,url)	
	{
		return $http(
			{
				method: 'PUT',
				url:url,
				data: data,
				headers: 
				{
					'Content-type': 'application/x-www-form-urlencoded'
				}
			});
	};
	
	
	
}]);