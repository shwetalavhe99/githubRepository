//Script for editing author information.

app.controller('editAuthorCtrl',['$scope','$http','$location','myService',function($scope,$http,$location,myService)
{
			$scope.empid = $location.search();
			var empid = $scope.empid.empid;
			console.log(empid);
		console.log("In edit controller");
			$scope.skills = [{l:'HTML'},
							{l:'CSS'},
							{l:'JAVASCRIPT'},
							{l:'NODEJS'},
							{l:'ANGULARJS'},
							];
		$scope.selection=[];
		// toggle selection for a given employee by name
		$scope.toggleSelection = function toggleSelection(skill) {
	    var idx = $scope.selection.indexOf(skill);

	    // is currently selected
	    if (idx > -1) {
	      $scope.selection.splice(idx, 1);
	    }

	    // is newly selected
	    else {
	      $scope.selection.push(skill);
	    }
	  };
		
		$scope.editAuthData = function()
		{
		var data = {
					empid : $scope.empid.empid,
					name : $scope.newName,
					email : $scope.newEmail,
					skills : $scope.selection,
					department : $scope.newDepartment,
					website : $scope.newWebsite
				};
       //API for editing author information.
	   var url = "http://172.27.12.104:3000/author/update";		
	   
	   //call  function update of 'myService' for update author.
		myService.update(data,url);			
	};
}]);

