//Script for deleting author from database.

app.controller('deleteAuthorCtrl',['$scope','$http','$location', function($scope,$http,$location)
{
	//get empid of clicked author in 'id' variable
	$scope.id = $location.search();	

		var data =$.param({
			empid : $scope.id.empid
		});
		
		//http method for deleting author.
				$http({				
				method: 'DELETE',
				url: 'http://172.27.12.104:3000/author/remove',
				data: data,
				headers: {
					'Content-type': 'application/x-www-form-urlencoded'
				}
			})
			.then(function(response) {
				console.log(response.data);
			}, function(rejection) {
				console.log(rejection.data);
			});
}]);
