//Script for adding new Book.
//Service used 'myService is in service.js script.'

app.controller("addbookCtrl", ['$scope','$http','myService',function ($scope,$http,myService)
{
	alert('In controller');
	$scope.availableon = [{a:'ebay'},
							{a:'flipkart'},
							{a:'Amazon'},
							];
		$scope.selection=[];		//Array for checklist items.
		// toggle selection for a given employee by name
		$scope.toggleSelection = function toggleSelection(availOn) {
	    var idx = $scope.selection.indexOf(availOn);

	    // is currently selected
	    if (idx > -1) {
	      $scope.selection.splice(idx, 1);
	    }

	    // is newly selected
	    else {
	      $scope.selection.push(availOn);
	    }
	  };
	 
	  console.log($scope.selection);
	  
	$scope.postData = function()
	{
		alert('In function');
	
		var data = {
                isbn: $scope.isbn,
                title: $scope.title,
                author:$scope.author,
                price:$scope.price,
				availableOn : $scope.selection 
			};
		//API for updating the author information.
        var url = "http://172.27.12.104:3000/book/new";		
		
		//Call the add function of MyService.
		myService.add(data,url);		
	};
	
}]);