//Script for deleting book from database.

app.controller('deleteBookCtrl',['$scope','$http','$location', function($scope,$http,$location)
{
	//get isbn of clicked book in 'isbn' variable
	$scope.isbn = $location.search();	
	
		var data =$.param({
			isbn : $scope.isbn.isbn
		});
			
		//http method for deleting book.
				$http({					
				method: 'DELETE',
				url: 'http://172.27.12.104:3000/book/remove',
				data: data,
				headers: {
					'Content-type': 'application/x-www-form-urlencoded'
				}
			})
			.then(function(response) {
				console.log(response.data);
			}, function(rejection) {
				console.log(rejection.data);
			});
}]);
