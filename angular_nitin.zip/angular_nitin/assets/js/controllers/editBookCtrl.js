//Script for editing author information.

app.controller('editBookCtrl',['$scope','$http','$location','myService',function($scope,$http,$location,myService)
{
			$scope.book = $location.search();
			
		console.log("In edit controller");
			$scope.availableon = [{a:'ebay'},
							{a:'flipkart'},
							{a:'Amazon'},
							];
		$scope.selection=[];
		// toggle selection for a given employee by name
		$scope.toggleSelection = function toggleSelection(availOn) {
	    var idx = $scope.selection.indexOf(availOn);

	    // is currently selected
	    if (idx > -1) {
	      $scope.selection.splice(idx, 1);
	    }

	    // is newly selected
	    else {
	      $scope.selection.push(availOn);
	    }
	  };
	 
		$scope.editBk = function()
		{
		var data = $.param({
					isbn : $scope.book.isbn,
					title : $scope.newTitle,
					author : $scope.newAuthor,
					price : $scope.newPrice,
					availableOn : $scope.selection 
				});
        
		//API for editing author information.
		var url = "http://172.27.12.104:3000/book/update";
		 
		 //call  function update of 'myService' for update book.
		myService.update(data,url);
		};
}]);

