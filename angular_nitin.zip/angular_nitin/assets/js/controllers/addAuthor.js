//Script for adding new Author.
//Service used 'myService is in service.js script.'

app.controller('addauthorCtrl', ['$scope','$http','myService',function ($scope,$http,myService) 
{
		alert('In controller');
		$scope.skills = [{l:'HTML'},
							{l:'CSS'},
							{l:'JAVASCRIPT'},
							{l:'NODEJS'},
							{l:'ANGULARJS'},
							];
		$scope.selection=[];		//Array for checklist(skills) items.
		// toggle selection for a given employee by name
		$scope.toggleSelection = function toggleSelection(skill) {
	    var idx = $scope.selection.indexOf(skill);

	    // is currently selected
	    if (idx > -1) {
	      $scope.selection.splice(idx, 1);
	    }

	    // is newly selected
	    else {
	      $scope.selection.push(skill);
	    }
	  };
	 
	  console.log($scope.selection);
	  
			$scope.postAuthData = function()
			{
			 var data ={
                empid: $scope.empid,
                name: $scope.name,
				email:$scope.email,
				skills :$scope.selection,
				department:$scope.department,
				website:$scope.website
			};
			//API for updating the author information.
			var url = "http://172.27.12.104:3000/author/new";	
			
			//Call the add function of MyService.
			myService.add(data,url);		
	};
	
}]);