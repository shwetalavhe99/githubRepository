//script for display the book list into the table.

app.controller('retrvData',['$scope','$http',function($scope,$http)
{
	//API to retrive the book list into the table.
	$http.get("http://172.27.12.104:3000/book/list")
	.then(function(response)
	{
		$scope.myData = response.data;
	});
	
}]);
