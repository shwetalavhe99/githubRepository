//Script for display particular clicked author information.

app.controller('displayAuthr',['$scope','$http','$location','$window', function($scope,$http,$location,$window)
{
	$scope.author = $location.search();
	
	$scope.data = false ;
	$http.get("http://172.27.12.104:3000/author/list")
	.then(function(response)
	{
		$scope.details = response.data;
		
		console.log($scope.author);
		for(var i in $scope.details)
		{
		//if author name matches with the name present in database, collect its all information in $scope.PostDataResponse
			if($scope.author.name == $scope.details[i].name)	
			{
				$scope.data = true;
				$scope.PostDataResponse = $scope.details[i];
				break;
			}
			
		}
			if($scope.data == false)	//if the clicked author is not present in database.
			{
				$window.alert("No Matches Found!");
				
			}
	});
}]);