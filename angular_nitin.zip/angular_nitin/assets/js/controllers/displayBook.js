//Script for display particular clicked Book information.

app.controller('displayBook',['$scope','$http','$location', function($scope,$http,$location)
{
	$scope.data = false ;
	
	$http.get("http://172.27.12.104:3000/book/list")
	.then(function(response)
	{
		$scope.detail = response.data;
		$scope.bookisbn = $location.search();
		
		for(var i in $scope.detail)
		{
		//if author name matches with the name present in database, collect its all information in $scope.PostDataResponse
			if($scope.bookisbn.isbn == $scope.detail[i].isbn)
			{
				$scope.data = true;
				$scope.PostDataResponse = $scope.detail[i];
			}
		}
	
	});
	
}]);