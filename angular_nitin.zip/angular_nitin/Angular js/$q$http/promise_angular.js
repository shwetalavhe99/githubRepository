var app = angular.module("app",[]);

app.service("githubService",function(){
	var defferd = $q.defer();


}); 